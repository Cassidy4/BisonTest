//
// Created by kamila on 14.01.2020.
//

#include "Param.hpp"

std::map<std::string, long long> variables;
std::map<std::string,  long long> forVar;
std::map<std::string,arrayInfo> arrays;
std::vector<std::string> allLines;


long long oneId = 41;
long long mOneId = 40;
const  long long resR = oneId;
 long long curR = resR + 1;

 long long lastInxId = 3;
 long long lastInxAddId = 21;
 long long lastIfId = 15;
 long long timesId = 16;

long long backUpMemory = 26;

std::map<std::string,  long long> inited;