#!/bin/bash
./calc < $1 > $2
