Autor kompilatora: Kamila Bojar
Index: 236456
Data: 31.01.2020

Sposób uruchamiania:
./kompilator.sh <wejście> <wyjście>

